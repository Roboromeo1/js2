function createGame(){
    document.body.innerHTML = "";
    var containerDiv = createDiv();
    containerDiv.classList.add("colourContainer");
    document.body.appendChild(containerDiv);
    for (var index=0;index<ColourList.length;index++){
      var currentColor = ColourList[index];
      console.log("Now processing"+currentColor);
      var boxDiv = createDiv();
      boxDiv.style.backgroundcolor = currentColor;
      containerDiv.appendChild(boxDiv);

    }
}


function loadApp(){

  console.log("game created");
  createGame();


}
window.onload = loadApp;
