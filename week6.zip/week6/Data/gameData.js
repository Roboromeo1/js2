window.ColourList = [
  "Red",
  "Yellow",
  "Blue",
]
